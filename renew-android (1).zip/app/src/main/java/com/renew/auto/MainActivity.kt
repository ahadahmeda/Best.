package com.renew.auto

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var minutes: EditText

    private fun btn(box: LinearLayout, label: String, f: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.setOnClickListener { f() }
        box.addView(b)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(40, 80, 40, 40)

        val info = TextView(this)
        info.textSize = 15f
        info.text = "Hourly Renew\nBlockerHero খুলে Uninstall protection-এর রিফ্রেশ আইকন চাপে।\n\n" +
            "ধাপ: ১) অ্যাক্সেসিবিলিটি চালু ২) Overlay অনুমতি ৩) ব্যাটারি সীমা বন্ধ ৪) Run now দিয়ে টেস্ট ৫) Start।\n" +
            "ফোন আনলক/স্ক্রিন-লক ছাড়া থাকলে সবচেয়ে ভালো চলে।\n\nঅন্তর (মিনিট, সর্বনিম্ন ১৫):"
        box.addView(info)

        minutes = EditText(this)
        minutes.inputType = InputType.TYPE_CLASS_NUMBER
        minutes.setText(Store.prefs(this).getInt("min", 60).toString())
        box.addView(minutes)

        btn(box, "১) অ্যাক্সেসিবিলিটি সেটিংস") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(box, "২) Overlay অনুমতি") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn(box, "৩) ব্যাটারি অপ্টিমাইজেশন সেটিংস") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        btn(box, "৪) Run now (টেস্ট)") {
            val sv = RenewService.inst
            if (sv == null) toast("আগে অ্যাক্সেসিবিলিটি চালু করুন") else { sv.run(); toast("চলছে...") }
        }
        btn(box, "৫) Start (নিয়মিত শিডিউল)") {
            val m = (minutes.text.toString().toIntOrNull() ?: 60).coerceAtLeast(15)
            Store.prefs(this).edit().putInt("min", m).putBoolean("on", true).apply()
            Store.scheduleNext(this)
            Store.log(this, "শিডিউল চালু: প্রতি $m মিনিট")
            refresh()
        }
        btn(box, "Stop") {
            Store.prefs(this).edit().putBoolean("on", false).apply()
            Store.cancel(this)
            Store.log(this, "শিডিউল বন্ধ")
            refresh()
        }
        btn(box, "ডিবাগ: স্ক্রিন কপি (৮ সেকেন্ডে BlockerHero খুলুন)") {
            toast("৮ সেকেন্ডের মধ্যে BlockerHero খুলুন")
            Handler(Looper.getMainLooper()).postDelayed({
                val ok = RenewService.inst?.dumpToClipboard() == true
                Store.log(this, if (ok) "স্ক্রিনের তথ্য ক্লিপবোর্ডে কপি হয়েছে" else "কপি করা যায়নি")
            }, 8000)
        }

        status = TextView(this)
        status.textSize = 13f
        status.setPadding(0, 30, 0, 0)
        box.addView(status)
        val sc = ScrollView(this)
        sc.addView(box)
        setContentView(sc)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun refresh() {
        val p = Store.prefs(this)
        status.text = "শিডিউল: " + (if (p.getBoolean("on", false)) "চালু (প্রতি ${p.getInt("min", 60)} মিনিট)" else "বন্ধ") +
            "\nঅ্যাক্সেসিবিলিটি: " + (if (RenewService.inst != null) "চালু" else "বন্ধ") +
            "\n\nলগ:\n" + (p.getString("log", "") ?: "")
    }

    override fun onResume() { super.onResume(); refresh() }
}
