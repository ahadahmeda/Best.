package com.renew.auto

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (!Store.prefs(c).getBoolean("on", false)) return
        Store.scheduleNext(c)
        val s = RenewService.inst
        if (s == null) Store.log(c, "অ্যাক্সেসিবিলিটি বন্ধ - রিনিউ হয়নি") else s.run()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) {
        if (Store.prefs(c).getBoolean("on", false)) {
            Store.scheduleNext(c)
            Store.log(c, "ফোন চালু হয়েছে, শিডিউল আবার চালু")
        }
    }
}
