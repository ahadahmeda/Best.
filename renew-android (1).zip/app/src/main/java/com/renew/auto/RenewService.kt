package com.renew.auto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

/**
 * Opens BlockerHero, finds the refresh icon next to "Completed days: x/y" (Uninstall protection)
 * and clicks it, then confirms any dialog and goes Home.
 */
class RenewService : AccessibilityService() {
    companion object {
        @Volatile var inst: RenewService? = null
        const val TARGET = "com.blockerhero"
        private val CONFIRM = listOf("yes", "ok", "confirm", "renew", "reset", "continue", "proceed", "restart")
    }

    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var deadline = 0L
    private var clickedAt = 0L
    private var before: String? = null
    private var ticks = 0
    private var confirms = 0

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun run() {
        if (running) return
        running = true; clickedAt = 0; before = null; ticks = 0; confirms = 0
        deadline = SystemClock.elapsedRealtime() + 35_000
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        @Suppress("DEPRECATION")
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
            "renew:wake"
        ).acquire(45_000)
        val li = packageManager.getLaunchIntentForPackage(TARGET)
        if (li == null) { finish("BlockerHero অ্যাপ পাওয়া যায়নি"); return }
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(li) } catch (e: Exception) { finish("অ্যাপ খুলতে পারেনি: ${e.message}"); return }
        h.postDelayed({ tick() }, 2500)
    }

    private fun tick() {
        if (!running) return
        ticks++
        val now = SystemClock.elapsedRealtime()
        val root = rootInActiveWindow
        if (root != null && root.packageName?.toString() == TARGET) {
            val cd = completed(root)
            if (clickedAt == 0L) {
                if (cd != null) {
                    before = cd.text?.toString()
                    if (clickRefresh(root, cd)) {
                        clickedAt = now
                        h.postDelayed({ tick() }, 1500); return
                    }
                } else prepare(root)
            } else {
                if (cd == null) {
                    if (confirms < 3 && confirm(root)) { confirms++; h.postDelayed({ tick() }, 1500); return }
                } else if (now - clickedAt > 3000) {
                    val after = cd.text?.toString()
                    finish("রিনিউ ক্লিক হয়েছে: [$before] -> [$after]"); return
                }
            }
        }
        if (now > deadline) {
            finish(if (clickedAt == 0L) "ব্যর্থ: রিফ্রেশ বোতাম পাওয়া যায়নি (ফোন লক? অ্যাপ অন্য পেজে?)"
                   else "ক্লিক হয়েছে কিন্তু ফল নিশ্চিত হয়নি")
            return
        }
        h.postDelayed({ tick() }, 800)
    }

    private fun finish(msg: String) {
        running = false
        Store.log(this, msg)
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    // ---------- node helpers ----------
    private fun completed(root: AccessibilityNodeInfo) =
        root.findAccessibilityNodeInfosByText("Completed days").firstOrNull()

    private fun walk(n: AccessibilityNodeInfo?, depth: Int = 0, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 40) return
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, f)
    }

    private fun bounds(n: AccessibilityNodeInfo): Rect { val r = Rect(); n.getBoundsInScreen(r); return r }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var hops = 0
        while (x != null && !x.isClickable && hops < 4) { x = x.parent; hops++ }
        if (x != null && x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val b = bounds(n)
        tapAt(b.exactCenterX(), b.exactCenterY())
        return true
    }

    private fun tapAt(x: Float, y: Float) {
        val p = Path(); p.moveTo(x, y)
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build(), null, null
        )
    }

    /** The refresh icon sits just right of the "Completed days" text, on the same row. */
    private fun clickRefresh(root: AccessibilityNodeInfo, cd: AccessibilityNodeInfo): Boolean {
        val r = bounds(cd)
        var best: AccessibilityNodeInfo? = null
        var bestLeft = Int.MAX_VALUE
        walk(root) { n ->
            if (n != cd) {
                val b = bounds(n)
                if (b.width() > 0 && b.height() > 0 && b.width() < dp(80f) &&
                    b.left >= r.right - dp(6f) && b.left <= r.right + dp(80f) &&
                    abs(b.centerY() - r.centerY()) <= r.height() && b.left < bestLeft
                ) { best = n; bestLeft = b.left }
            }
        }
        val t = best
        if (t != null) return clickNode(t)
        // fallback: blind tap where the icon is in the screenshot (just right of the text)
        tapAt(r.right + resources.displayMetrics.widthPixels * 0.024f, r.exactCenterY())
        return true
    }

    private fun confirm(root: AccessibilityNodeInfo): Boolean {
        var hit: AccessibilityNodeInfo? = null
        walk(root) { n ->
            val t = n.text?.toString()?.trim()?.lowercase()
            if (hit == null && t != null && t in CONFIRM) hit = n
        }
        val t = hit ?: return false
        return clickNode(t)
    }

    /** Select the Blocking tab and scroll until "Completed days" appears. */
    private fun prepare(root: AccessibilityNodeInfo) {
        if (ticks == 1) {
            var tab: AccessibilityNodeInfo? = null
            walk(root) { n -> if (tab == null && n.text?.toString()?.trim().equals("Blocking", true)) tab = n }
            tab?.let { clickNode(it) }
        } else if (ticks % 3 == 0) {
            var sc: AccessibilityNodeInfo? = null
            walk(root) { n -> if (sc == null && n.isScrollable) sc = n }
            sc?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
        }
    }

    /** Debug helper: copies the current screen's node tree to the clipboard so it can be shared. */
    fun dumpToClipboard(): Boolean {
        val root = rootInActiveWindow ?: return false
        val sb = StringBuilder()
        fun rec(n: AccessibilityNodeInfo, d: Int) {
            val b = bounds(n)
            sb.append("  ".repeat(d)).append(n.className).append(" text=").append(n.text)
                .append(" desc=").append(n.contentDescription).append(" id=").append(n.viewIdResourceName)
                .append(" click=").append(n.isClickable).append(" ").append(b.toShortString()).append('\n')
            for (i in 0 until n.childCount) n.getChild(i)?.let { rec(it, d + 1) }
        }
        rec(root, 0)
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("tree", sb.toString()))
        return true
    }
}
