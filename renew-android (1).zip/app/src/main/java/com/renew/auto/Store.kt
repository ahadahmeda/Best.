package com.renew.auto

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("p", 0)

    fun log(c: Context, msg: String) {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        val old = prefs(c).getString("log", "") ?: ""
        val lines = (old.split("\n").filter { it.isNotBlank() } + "$t  $msg").takeLast(40)
        prefs(c).edit().putString("log", lines.joinToString("\n")).apply()
    }

    private fun pi(c: Context) = PendingIntent.getBroadcast(
        c, 1, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Schedules the next run after the saved interval (minutes). Survives doze (may drift a few minutes). */
    fun scheduleNext(c: Context) {
        val min = prefs(c).getInt("min", 60).coerceAtLeast(15)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + min * 60_000L, pi(c))
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c))
    }
}
